# Programacao Tenis

Primeira versao do app de agendamento de quadras, com interface responsiva em HTML, CSS e JavaScript. O arquivo `index.html` e o ponto de entrada para hospedagem estatica.

## Rodar localmente

1. Instale o PHP 8.1 ou superior e adicione o executavel ao `PATH` se quiser usar o servidor local.
2. Na raiz do projeto, execute:

```powershell
php -S localhost:8080
```

3. Abra `http://localhost:8080/index.html`.

O app usa o Supabase para autenticação, quadras e reservas. O administrador precisa ter o papel `admin` na tabela `profiles`.

Para publicar sem PHP, use `index.html` em Cloudflare Pages, Netlify ou GitHub Pages.

## Supabase

1. Crie um projeto no Supabase.
2. Execute o arquivo `supabase.sql` no SQL Editor.
3. Ative Email/Password e Google em **Authentication > Providers**.
4. Promova o primeiro usuario a administrador usando o `update` comentado no final do SQL.
5. Se o banco já existia, execute também `supabase-migration-horarios.sql` para aplicar a grade diária de 06:00 a 22:00 em blocos de 2 horas.
6. Execute `supabase-migration-recorrencia.sql` para habilitar reservas diária, semanal e mensal e o limite de 30 dias consecutivos.

O administrador inicial usa o login `progtenis` e o e-mail `programacaotennis@gmail.com`. Ao cadastrar essa conta pelo formulário, ela recebe automaticamente o papel `admin`; a senha deve ser definida no cadastro. O painel permite alterar e-mail e senha depois. A criação de usuário não pode ser feita por SQL sem expor a chave administrativa do Supabase.

## Escopo da primeira entrega

- Login, cadastro manual e ponto de entrada para Google.
- Perfil de membro e perfil administrador.
- Selecao de quadra, data e horario.
- Confirmação de reserva persistida no Supabase, com bloqueio de horário ocupado.
- Painel administrativo com quadras, disponibilidade e administradores.
- Esquema inicial com RLS para `profiles`, `courts`, `availability` e `bookings`.